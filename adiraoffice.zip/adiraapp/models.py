from django.db import models
from django.contrib.auth.models import User

class CreateNewUserModel(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    password = models.CharField(max_length=100, null=True)
    phone = models.CharField(max_length=100, null=True)
    is_deleted = models.BooleanField(default=False)
    

class AttendancePunchInModel(models.Model):
    user = models.ForeignKey(CreateNewUserModel, on_delete=models.SET_NULL, null=True)
    punchin_datetime = models.DateTimeField()
    punchout_datetime = models.DateTimeField()
    latitude = models.CharField(max_length=100)
    longitude = models.CharField(max_length=100)