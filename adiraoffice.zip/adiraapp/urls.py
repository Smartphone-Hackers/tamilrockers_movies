from django.urls import path
from adiraapp import views

urlpatterns = [
    path('dashboard', views.Dashboard.as_view()),
    path('create-user', views.CreateUserView.as_view()),
    path('create-user/<int:id>', views.CreateUserView.as_view()),
    path('users-list', views.UsersListView.as_view()),
    path('attendance-punchin', views.AttendancePunchInView.as_view()),
    path('attendance-list', views.AttendanceListView.as_view()),
]