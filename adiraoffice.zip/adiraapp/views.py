from django.shortcuts import render, redirect
from django.views import View
from django.http import JsonResponse
from django.contrib.auth.models import User
from adiraapp import models
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import permission_required
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.contrib import messages
from datetime import datetime, timedelta
import calendar

@method_decorator(login_required(login_url="/"), name="dispatch")
class Dashboard(View):
    template_name = 'dashboard.html'
    def get(self, request):
        return render(request, self.template_name)

@method_decorator(login_required(login_url="/"), name="dispatch")
class UsersListView(View):
    template_name = 'users-list.html'
    def get(self, request):
        datas = {
            'users': models.CreateNewUserModel.objects.filter(user__is_superuser=False)
        }
        return render(request, self.template_name, context=datas)

@method_decorator(login_required(login_url="/"), name="dispatch")
class CreateUserView(View):
    template_name = 'create-user.html'
    def get(self, request, id=None):
        try:
            userobj = models.CreateNewUserModel.objects.get(id=id)
            datas = {'userobj': userobj}
        except:
            datas = {}
        return render(request, self.template_name, context=datas)
    
    def post(self, request, id=None):
        username = request.POST.get("username")
        gmail = request.POST.get("gmail")
        phone_number = request.POST.get("phone-number")
        password = request.POST.get("password")
        confirm_password = request.POST.get("confirm-password")

        try:
            if password != confirm_password:
                response_data = {
                    "status": "error",
                    "msg": "Password & Confirm Password not Same!",
                }
                return JsonResponse(response_data)
        
            if id is None:
                chk_user = User.objects.filter(username=username)
                if chk_user:
                    response_data = {
                        "status": "error",
                        "msg": f"{username}. Already Exist!",
                    }
                    return JsonResponse(response_data)

                user = User.objects.create_user(
                    username=username, email=gmail, password=password
                )
                user.save()

                try:
                    new_user = models.CreateNewUserModel(
                        user=user, password=password, phone=phone_number
                    )
                    new_user.save()
                except Exception as e:
                    response_data = {"status": "error", "msg": f"Error: {e}"}
                    return JsonResponse(response_data)

                response_data = {"status": "success", "msg": f"{username}. Created.."}
            else:
                try:
                    cuser = models.CreateNewUserModel.objects.get(id=id)
                    user = cuser.user
                    user.username = username
                    user.set_password(password)
                    user.email = gmail
                    user.save()

                    cuser.phone = phone_number
                    cuser.password = password
                    cuser.save()
                except Exception as e:
                    response_data = {"status": "error", "msg": f"Error: {e}"}
                    return JsonResponse(response_data)

                response_data = {"status": "success", "msg": f"{username}. Updated.."}
        except Exception as e:
            response_data = {"status": "error", "msg": f"Error: {e}"}

        return JsonResponse(response_data)

@method_decorator(login_required(login_url="/"), name="dispatch")
class AttendancePunchInView(View):
    template_name = 'attendance-punchin.html'
    def get(self, request):
        return render(request, self.template_name)

@method_decorator(login_required(login_url="/"), name="dispatch")
class AttendanceListView(View):
    template_name = 'attendance-list.html'
    def get(self, request):
        is_production = False
        if is_production:
            t = datetime.today() + timedelta(hours=5, minutes=30)
        else:
            t = datetime.today()
        monthenddate = calendar.monthrange(t.year, t.month)[1]
        monthscolumns = [ 
            (
                datetime(day=i, month=t.month, year=t.year), 
                i, 
                datetime(day=i, month=t.month, year=t.year).strftime('%a')
            ) 
            for i in range(1, monthenddate+1) 
        ]
        month_year = t.strftime('%b%Y')
        datas = {
            'month_year': month_year,
            'monthscolumns': monthscolumns,
            'users': models.CreateNewUserModel.objects.all()
        }
        return render(request, self.template_name, context=datas)

class LoginView(View):
    template_name = 'login.html'
    def get(self, request):
        return render(request, self.template_name)
    
    def post(self, request):
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect("/adira/dashboard")
        else:
            return redirect("/")
        
class Logout(View):
    def get(self, request):
        logout(request)
        return redirect("/")